package hotelReservation;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/profileServlet")
public class profileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Session එකෙන් user data එක ගන්න
		entryModel loggedUser = (entryModel) request.getSession().getAttribute("loggedUser");

		if (loggedUser != null) {
			// userDetails.jsp එකට data එක යවන්න
			request.setAttribute("userList", loggedUser); // userList කියන attribute එක
			request.getRequestDispatcher("userDetails.jsp").forward(request, response);
		} else {
			// login නොවුනොත්
			response.sendRedirect("login.jsp");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
