package hotelReservation;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/logoutServlet")
public class logoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Session එක invalidate කරන්න
		HttpSession session = request.getSession(false); // existing session එකක් තියනවද බලනවා

		if (session != null) {
			session.invalidate(); // session එක ඉවත් කරනවා (logout)
		}

		// Login පිටුවට redirect කරන්න
		response.sendRedirect("index.jsp");
	}
}
