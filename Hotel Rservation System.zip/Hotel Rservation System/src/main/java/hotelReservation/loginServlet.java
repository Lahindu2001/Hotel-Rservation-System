package hotelReservation;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get email & password from login.jsp
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Validate login with DB
        List<entryModel> user = entryController.loginValidate(email, password);

        if (!user.isEmpty()) {
            HttpSession session = request.getSession();
            session.setAttribute("loggedUser", user.get(0));

            response.getWriter().println("<script>alert('Login Successfully'); window.location='index.jsp';</script>");
        }
        else {
            // Login failed
            request.setAttribute("errorMessage", "Invalid email or password!");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
